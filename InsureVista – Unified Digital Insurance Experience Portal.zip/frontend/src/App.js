
import React, { useState } from "react";

function App() {
  const [name, setName] = useState("");
  const [type, setType] = useState("");

  const submitClaim = async () => {
    await fetch("http://localhost:5000/api/claims", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ customer: name, claimType: type })
    });
    alert("Claim Submitted");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>InsureVista – Insurance Portal</h2>
      <input placeholder="Customer Name" onChange={e => setName(e.target.value)} />
      <input placeholder="Claim Type" onChange={e => setType(e.target.value)} />
      <button onClick={submitClaim}>Submit Claim</button>
    </div>
  );
}

export default App;
