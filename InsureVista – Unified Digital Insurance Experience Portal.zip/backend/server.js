
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
app.use(cors());
app.use(bodyParser.json());

let claims = [];
let policies = [];

app.post("/api/claims", (req, res) => {
  const claim = { id: claims.length + 1, ...req.body, status: "Submitted" };
  claims.push(claim);
  res.json({ message: "Claim submitted successfully", claim });
});

app.get("/api/claims", (req, res) => {
  res.json(claims);
});

app.post("/api/policies", (req, res) => {
  const policy = { id: policies.length + 1, ...req.body, status: "Active" };
  policies.push(policy);
  res.json({ message: "Policy created successfully", policy });
});

app.get("/api/policies", (req, res) => {
  res.json(policies);
});

app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
});
