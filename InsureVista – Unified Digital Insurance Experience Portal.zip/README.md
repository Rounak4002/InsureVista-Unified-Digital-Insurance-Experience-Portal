
# InsureVista – Unified Digital Insurance Experience Portal
---

## Rounak Pattanaik | ITER, SOA University

### Description
InsureVista is a full-stack insurance management portal that provides a unified digital interface for customers and operations teams to manage insurance claims and policies. The platform integrates a modern frontend with backend services to deliver an end-to-end insurance workflow.

### Extended Description
InsureVista focuses on building a real-world insurance technology platform by combining frontend usability with backend business logic. Customers can interact with a simple dashboard to submit claims and view insurance-related information, while backend services manage claim and policy data through RESTful APIs.

The project models core insurance operations such as claim submission, policy creation, and status tracking. It emphasizes full-stack data flow, API integration, and separation of frontend and backend responsibilities. The architecture is intentionally kept modular and beginner-friendly, allowing easy extension to authentication, analytics dashboards, or cloud deployment.

By implementing both client-side and server-side components, InsureVista demonstrates an understanding of how modern web applications are built and maintained in production environments.

### Key Features
- Full-stack insurance portal with frontend and backend integration
- Claim submission and policy creation workflows
- REST API-based backend services
- Simple and interactive user interface
- Modular structure for future scalability

### Tech Stack
- Frontend: React (JavaScript)
- Backend: Node.js, Express
- APIs: RESTful services
- Concepts: Full-stack development, API integration, business workflows

### Learning Outcomes
- Gained hands-on experience in full-stack application development
- Learned to integrate frontend UI with backend APIs
- Strengthened understanding of real-world insurance workflows
- Improved knowledge of REST services and system design
